# Smartphone Usage and Student Productivity Analysis using R
# Course: Data Science Using R (1ADPC306) | Roll No. 3023 | Tanuja Ravindra Pawar

# Install libraries if not already installed
packages <- c("ggplot2", "dplyr")
new_packages <- packages[!(packages %in% installed.packages()[, "Package"])]
if (length(new_packages)) install.packages(new_packages)

# Load libraries
library(ggplot2)
library(dplyr)

dir.create("outputs", showWarnings = FALSE)

# Sample dataset (15 students)
student_data <- data.frame(
  Student = paste0("S", 1:15),
  ScreenTime = c(2.5, 6.5, 4.0, 7.5, 3.0, 5.5, 8.0, 3.5,
                 6.0, 2.0, 4.5, 7.0, 5.0, 3.0, 6.8),
  SleepHours = c(7.5, 6.0, 7.0, 5.5, 8.0, 5.5, 6.0, 7.0,
                 6.5, 8.0, 6.0, 5.0, 7.5, 7.0, 4.5),
  StudyHours = c(4.5, 2.5, 3.5, 2.0, 4.0, 3.5, 1.5, 3.0,
                 3.0, 5.0, 2.5, 1.5, 4.0, 3.5, 2.0),
  Productivity = c(82, 58, 68, 47, 79, 57, 42, 72,
                   50, 88, 67, 44, 64, 84, 40)
)
print(student_data)

# Summary statistics
student_data %>% select(-Student) %>% summary()

# Shared plot theme
base_theme <- theme_minimal() +
  theme(plot.title = element_text(size = 16, face = "bold", hjust = 0.5))

# Scatter plots with regression lines
scatter_plot <- function(x, y, xlab, ylab, colour, file) {
  p <- ggplot(student_data, aes(x = .data[[x]], y = .data[[y]])) +
    geom_point(size = 3.5, colour = colour) +
    geom_smooth(method = "lm", se = TRUE, colour = "#D7263D", fill = "#D7263D", alpha = 0.12) +
    labs(title = paste(xlab, "vs", ylab), x = xlab, y = ylab) +
    base_theme
  print(p)
  ggsave(file.path("outputs", file), p, width = 8, height = 5)
}
scatter_plot("ScreenTime", "StudyHours",   "Screen Time (hours/day)", "Study Hours",        "#00A8E8", "scatter_screen_study.png")
scatter_plot("ScreenTime", "Productivity", "Screen Time (hours/day)", "Productivity Score", "#D7263D", "scatter_screen_productivity.png")
scatter_plot("SleepHours", "Productivity", "Sleep Hours",             "Productivity Score", "#1B998B", "scatter_sleep_productivity.png")
scatter_plot("StudyHours", "Productivity", "Study Hours",             "Productivity Score", "#F59E0B", "scatter_study_productivity.png")

# Histogram of screen time
p_hist <- ggplot(student_data, aes(x = ScreenTime)) +
  geom_histogram(binwidth = 1, fill = "#00A8E8", color = "white") +
  labs(title = "Distribution of Smartphone Screen Time",
       x = "Screen Time (hours/day)", y = "Number of Students") +
  base_theme
print(p_hist)
ggsave("outputs/histogram_screen_time.png", p_hist, width = 8, height = 5)

# Bar chart of productivity scores
p_bar <- ggplot(student_data, aes(x = reorder(Student, -Productivity), y = Productivity, fill = Student)) +
  geom_bar(stat = "identity") +
  labs(title = "Productivity Score of Students", x = "Student", y = "Productivity Score") +
  base_theme + theme(legend.position = "none")
print(p_bar)
ggsave("outputs/bar_productivity.png", p_bar, width = 8, height = 5)

# Correlation analysis
cor_matrix <- student_data %>% select(-Student) %>% cor() %>% round(2)
print(cor_matrix)

# Correlation heatmap
cor_df <- as.data.frame(as.table(cor_matrix))
p_heat <- ggplot(cor_df, aes(x = Var1, y = Var2, fill = Freq)) +
  geom_tile(color = "white") +
  geom_text(aes(label = Freq), size = 5) +
  scale_fill_gradient2(low = "#D7263D", mid = "white", high = "#1B998B",
                       midpoint = 0, limits = c(-1, 1)) +
  labs(title = "Correlation Heatmap", x = "", y = "", fill = "r") +
  base_theme
print(p_heat)
ggsave("outputs/correlation_heatmap.png", p_heat, width = 8, height = 5)

# Low vs high screen time comparison
student_data %>%
  mutate(Group = ifelse(ScreenTime <= 4.5, "Up to 4.5 h",
                        ifelse(ScreenTime >= 6, "6 h or more", "Between"))) %>%
  group_by(Group) %>%
  summarise(Students = n(), AvgProductivity = round(mean(Productivity), 1))
