# Smartphone Usage and Student Productivity Analysis using R

Micro Project for **Data Science Using R (1ADPC306)**
Annasaheb Dange College of Engineering and Technology (ADCET), Ashta

**Author:** Tanuja Ravindra Pawar | **Roll No.:** 3023 | **URN:** 1024091033

## About
Analyses how smartphone screen time, sleep hours and study hours relate to student productivity, using a 15-student sample dataset. Built with `ggplot2` and `dplyr`.

## Key findings
- Screen time vs productivity: r = -0.97 (strongest relationship)
- Screen time vs study hours: r = -0.87
- Sleep hours vs productivity: r = 0.85; study hours vs productivity: r = 0.85
- Students with up to 4.5 h/day screen time averaged about 77 productivity points, against about 47 for 6 h/day or more

The sample is small (15 students), so these results show association, not cause and effect.

## Project structure
```
analysis.R              R script: dataset, plots, correlation analysis
data/student_data.csv   The 15-student dataset
dashboard/index.html    Interactive dashboard (open in any browser)
outputs/                PNG plots saved when analysis.R is run
```

## How to run
1. Open `analysis.R` in RStudio.
2. Run the script. Required packages (`ggplot2`, `dplyr`) install automatically.
3. Plots are shown in RStudio and saved to `outputs/`.

## Dashboard
Open `dashboard/index.html` in a browser, or view it online with GitHub Pages
(Settings > Pages > Deploy from branch `main` > folder `/ (root)`), then visit
`https://YOUR-USERNAME.github.io/smartphone-productivity-analysis-r/dashboard/`.
